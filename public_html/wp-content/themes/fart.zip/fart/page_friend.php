<?php
/*
Template Name: Page Friend
*/
?>

<?php get_header(); ?>

                <div class="ace-paper-stock">
                    <main class="ace-paper clearfix">
                        <div class="ace-paper-cont clear-mrg">
						
						<!-- START: PAGE CONTENT -->

    <div class="padd-box">

        <section class="section clear-mrg">
            <h2 class="title-lg text-upper">故事里的你是这样的</h2>

            <div class="padd-box-sm clear-mrg">
<?php
	$limit = get_option('posts_per_page');
	$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
	query_posts('category_name=man&showposts=' . $limit=6 . '&paged=' . $paged);
	$wp_query->is_archive = true; $wp_query->is_home = false;
?>
<?php while (have_posts()) : the_post(); ?>
                <div class="ref-box brd-btm hreview">
                    <div class="ref-avatar">
                        <a href="<?php the_permalink(); ?>" rel="catch_that_image"><img src="<?php echo catch_that_image() ?>" alt=""  height="54" width="54"></a>
                    </div>

                    <div class="ref-info">
                        <div class="ref-author">
                            <strong><a href="<?php the_permalink(); ?>" rel="the_title"><?php the_title(); ?></a></strong>
                            <span><a href="<?php the_permalink(); ?>" rel="the_time"><?php the_time('Y年n月j日') ?></a></span>
                        </div>
                            <p>
								<a href="<?php the_permalink(); ?>" rel="the_excerpt"><?php the_excerpt(); ?></a>
                            </p>
                    </div>
					<hr>
                </div><!-- .ref-box -->
			<?php endwhile; ?>

            </div><!-- .padd-box-sm -->
        </section><!-- .section -->
	<div class="wp_nav"><div class="page_navi"><?php par_pagenavi(9); ?></div>  </div>
    </div><!-- .padd-box -->

<!-- END: PAGE CONTENT -->
						
                </div><!-- .ace-paper-cont -->
            </main><!-- .ace-paper -->
        </div><!-- .ace-paper-stock -->

        </div><!-- .ace-container -->
    </div><!-- #ace-content -->

	<?php get_sidebar(); ?>
<?php get_footer(); ?>
