<?php get_header(); ?>
<div class="ace-paper-stock">
	<main class="ace-paper clearfix">
	<div class="ace-paper-cont clear-mrg">
						
    <div class="padd-box clear-mrg">

<div id="main-container" class="container">
	<div class="row frontpage">
		<div class="col-md-8">
			<div class="fp-one">
				<div id="carousel-one" class="carousel slide">
					<?php
						query_posts('showposts=1&category_name=jrtj'); //cat=-1为排除ID为1的分类下文章showposts=3&cat=33
						while(have_posts()) : the_post(); ?>
					<div class="carousel-inner">
						<div class="item active">
							<a href="<?php the_permalink(); ?>"  title="林洋洋博客 | 生 活 荐 读 logo"><?php the_post_thumbnail(); ?></a>
							<div  class="fp-one-imagen-footer" title="林洋洋博客 | 生 活 荐 读"><a href="?cat=386">生 活 荐 读</a></div>
							<div class="fp-one-cita-wrapper">
								<div class="fp-one-titulo-pubdate">
<span class="posted-on">热 夏</span>
									<p class="dom" title="林洋洋博客 | 荐 读 七 月">7</p>
										<center><div class="post-header-info">
										<span class="posted-on"><!--<?php the_time('Y年n月j日') ?>-->月</span>
										</div></center>
								</div>
								<div class="fp-one-cita">
									<p><a href="<?php the_permalink(); ?>" title="林洋洋博客 | 生 活 荐 读 短 文"><?php the_excerpt(); ?></a></p>
								</div>
								<div class="clearfix"></div>
							</div>
                        </div>
					</div>
					<?php endwhile; ?>
				</div>
			</div>
		</div>
    <div class="col-md-4">
        <div class="row">
            <div class="col-md-12">
                <div class="fp-one-articulo">
				<h4  title="林洋洋博客 | 最 新 公 告">最新 公告</h4>
                    <?
						$args=array(
						'numberposts'=>1,
						'meta_key'=>'views',
						'cat'=>204
						);
						$rand_posts=get_posts($args);
						foreach($rand_posts as $post){
						setup_postdata($post);
						?><a href="<?php $category = get_the_category(); $category_id= get_cat_id($category[0]->cat_name); echo '?cat='.$category_id; ?>" title="<?php $category = get_the_category(); echo $category[0]->cat_name; ?>"><h4 title="林洋洋博客 | 公 告 消 息">公告 消息</h4></a><?}?>
                    <ul class="list-unstyled pasado">
<?
						$args=array(
						'numberposts'=>7,
						'meta_key'=>'views',
						'cat'=>204
						);
						$rand_posts=get_posts($args);
						foreach($rand_posts as $post){
						setup_postdata($post);
						?>
                        <li>
                            <span class="text-muted"><?php the_time('') ?>&nbsp;|&nbsp;</span>
                                <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
                        </li><?}?>
                    </ul>						
                </div>


               <div class="fp-one-cuestion">
               <h4  title="林洋洋博客 | 站 点 热 门">站点 热门</h4>
                     <ul class="list-unstyled pasado">
						<?
						$args=array(
						'numberposts'=>8,
						'orderby'=>'meta_value_num',//按点击量排序
						'meta_key'=>'views',
						'cat'=>398
						);
						$rand_posts=get_posts($args);
						foreach($rand_posts as $post){
						setup_postdata($post);
						?>
                        <li>
                            <span class="text-muted">
<a href="<?php $category = get_the_category(); $category_id= get_cat_id($category[0]->cat_name); echo '?cat='.$category_id; ?>" title="<?php $category = get_the_category(); echo $category[0]->cat_name; ?>"><?php $category = get_the_category();
echo $category[0]->cat_name;?></a>&nbsp;|&nbsp;</span>
<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
                        </li>
						<?}?>
                    </ul>
                </div>
            </div>
            
        </div>
    </div>
</div>

<!--<div class="container">
    <div id="main">
        <div class="carousel">

    <div class="content">
        <ul><a class="carousel-prev" href="detail.html">Previous</a>
								<?php
							query_posts('showposts=4&category_name=book-myself'); //cat=-1为排除ID为1的分类下文章showposts=3&cat=33
						while(have_posts()) : the_post(); ?>
            <li>
                <div class="image">
                    <a href="detail.html"></a>
                    <?php the_post_thumbnail(); ?>
                </div>
                <div class="title">
                    <h3><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
                </div>
                <div class="location">Palo Alto CA</div>
                <div class="area">
                    <span class="key">Area:</span>
                    <span class="value">750m<sup>2</sup></span>
                </div>
                <div class="bathrooms"><div class="inner">3</div></div>
            </li>
			<?php endwhile; ?>	
        </ul>
    </div>
</div></div>
</div>-->

<div class="pf-wrap">
    <div class="pf-grid">
        <div class="pf-grid-sizer"></div><!-- used for sizing -->
			<?php
				query_posts('showposts=4&category_name=story'); //cat=-1为排除ID为1的分类下文章showposts=3&cat=33
				while(have_posts()) : the_post(); ?>
        <div class="pf-grid-item  Reading photography design">
            <div class="project">
                <figure class="portfolio-figure">
                    <?php the_post_thumbnail(); ?>
                </figure>
                <div class="portfolio-caption text-center">
                    <div class="valign-table">
                        <div class="valign-cell">
                            <h2 class="text-upper"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            <p><span class="posted-on"><?php the_time('Y年n月j日') ?></span>
										&nbsp;<span class="post-author vcard"> | &nbsp;<span class="ace-icon ace-icon-folder-open-o"></span>&nbsp;<a href="<?php $category = get_the_category(); $category_id= get_cat_id($category[0]->cat_name); echo '?cat='.$category_id; ?>" title="<?php $category = get_the_category(); echo $category[0]->cat_name; ?>"><?php $category = get_the_category();
echo $category[0]->cat_name;?></a><!--<?php the_tags('', ', ', ''); ?>--></span></p>
                            <a href="<?php the_permalink(); ?>" class="pf-btn-view btn btn-primary">View</a>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- .pf-grid-item -->
		<?php endwhile; ?>		
	
	</div><!-- .pf-grid -->
</div><!-- .pf-wrap -->	
<br>
<center><div class="pf-wrap">
    <div class="pf-filter padd-box">
        <button data-filter=""></button>
		<a href="?page_id=545"><button data-filter=".Reading " title="林洋洋博客 | 安静的看一本书！ 按目录学习更高效！">我  &nbsp;&nbsp;的  &nbsp;&nbsp;阅  &nbsp;&nbsp;读</button></a>
    </div>
</div></center>		
	<div class="pf-wrap">

    <div class="pf-grid">
        <div class="pf-grid-sizer"></div><!-- used for sizing -->
						<?php
							query_posts('showposts=4&category_name=book-myself'); //cat=-1为排除ID为1的分类下文章showposts=3&cat=33
						while(have_posts()) : the_post(); ?>
        <div class="pf-grid-item Reading photography design">
            <div class="project">
                <figure class="portfolio-figure">
                    <?php the_post_thumbnail(); ?>
                </figure>

                <div class="portfolio-caption text-center">
                    <div class="valign-table">
                        <div class="valign-cell">
                            <h2 class="text-upper"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
                            <p><span class="posted-on"><?php the_time('Y年n月j日') ?></span>
										&nbsp;<span class="post-author vcard"> | &nbsp;<span class="ace-icon ace-icon-bookmark-o"></span>&nbsp;<?php the_tags('', ', ', ''); ?></span></p>
                            <a href="<?php the_permalink(); ?>" class="pf-btn-view btn btn-primary">View</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
						<?php endwhile; ?>		
	</div><!-- .pf-grid -->
</div><!-- .pf-wrap -->	
</br>
<!--<center>
<section class="section">
            <div class="row">
                <div class="col-sm-3 clear-mrg">
					<a href="?page_id=1436"><img src="<?php bloginfo('template_url'); ?>/img/uploads/avatar/book_lcj_logok.png" alt="林洋洋博客 | 定期专题" title="林洋洋博客 | 定期专题"></a>
                </div>
<div class="col-sm-3 clear-mrg">
					<a href="?page_id=1463"><img src="<?php bloginfo('template_url'); ?>/img/uploads/avatar/book_gdxs_logok.png" alt="林洋洋博客 | 定期专题" title="林洋洋博客 | 定期专题"></a>
                </div>
<div class="col-sm-3 clear-mrg">
					<a href="?page_id=1557"><img src="<?php bloginfo('template_url'); ?>/img/uploads/avatar/book_ys_logok.png" alt="林洋洋博客 | 定期专题" title="林洋洋博客 | 定期专题"></a>
                </div>
				<div class="col-sm-3 clear-mrg">
					<a href="?page_id=915"><img src="<?php bloginfo('template_url'); ?>/img/uploads/avatar/book_cyyxs_logok.png"  alt="林洋洋博客 | 音视频分享" title="林洋洋博客 | 音视频分享"></a>
                </div>
				<div class="col-sm-3 clear-mrg" style="margin-top:10px">
					<a href=""><img src="<?php bloginfo('template_url'); ?>/img/uploads/avatar/wdhyh_logok.png"  alt="林洋洋博客 | 我的回忆盒" title="林洋洋博客 | 我的回忆盒"></a>
                </div>
				<div class="col-sm-3 clear-mrg" style="margin-top:10px">
					<a href="?page_id=346"><img src="<?php bloginfo('template_url'); ?>/img/uploads/avatar/wdjlxc_logok.png"  alt="林洋洋博客 | 我的记录相册" title="林洋洋博客 | 我的记录相册"></a>
                </div>
            </div>
        </section>
</center>-->

<article class="post hentry">
				<div class="post-media">
					<div class="post-slider slider">
						<?php
							query_posts('showposts=2&category_name=imageindex');
							while(have_posts()) : the_post(); ?>
						<div>
								<?php the_post_thumbnail(); ?>

                </div>
            </div>


						</div>
						<?php endwhile; ?>
					</div>


<center><div class="post-header-info">
	<span class="posted-on">感谢ONe故事、OnE书、oNE歌、onE博客造就了我的sKy。</span>
</div></center>
				</div>

			</article>
</div>
		
	</div><!-- .pf-grid -->
</div><!-- .pf-wrap -->
					

    </div><!-- .padd-box -->
<!-- END: PAGE CONTENT -->

    </div><!-- .padd-box -->
<!-- END: PAGE CONTENT -->
						
                </div><!-- .ace-paper-cont -->
            </main><!-- .ace-paper -->
        </div><!-- .ace-paper-stock -->

        </div><!-- .ace-container -->
    </div><!-- #ace-content -->

	<?php get_sidebar(); ?>
<?php get_footer(); ?>