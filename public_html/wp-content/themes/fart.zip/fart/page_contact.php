<?php
/*
Template Name: Page Contact
*/
?>

<?php get_header(); ?>

                <div class="ace-paper-stock">
                    <main class="ace-paper clearfix">
                        <div class="ace-paper-cont clear-mrg">
						
						<!-- START: PAGE CONTENT -->

    <h2 class="title-lg text-upper padd-box">加入到我的故事中去</h2>

    <!--<div class="padd-box-xs">
        <header class="contact-head">
            <ul class="ace-social primary-social clear-list">
                <li><a><span class="ace-icon ace-icon-facebook"></span></a></li>
                <li><a><span class="ace-icon ace-icon-twitter"></span></a></li>
                <li><a><span class="ace-icon ace-icon-google-plus"></span></a></li>
                <li><a><span class="ace-icon ace-icon-instagram"></span></a></li>
                <li><a><span class="ace-icon ace-icon-pinterest"></span></a></li>
				<li><a><span class="ace-icon ace-icon-twitter"></span></a></li>
				<li><a><span class="ace-icon ace-icon-twitter"></span></a></li>
				<li><a><span class="ace-icon ace-icon-pinterest"></span></a></li>
            </ul>
            <p class="title text-upper">fell free to contact me the core of your marketing</p>
        </header>
    </div>-->

    <div class="padd-box-sm">
  <?php if (have_posts()) : the_post(); update_post_caches($posts); ?>
  <!--<?php the_content(); ?>-->
               <form action="#" method="post" class="contact-form">

            <div class="form-group">
                <label class="form-label" for="author">你 的 昵 称</label>
                <div class="form-item-wrap">
                    <input id="author" class="form-item" type="text">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="email">你 的 邮 箱</label>
                <div class="form-item-wrap">
                    <input id="email" class="form-item" type="email" required="required">
                </div>
            </div>

            <div class="form-group"> 
                <label class="form-label" for="url">你 的 标 题</label>
                <div class="form-item-wrap">
                    <input id="url" class="form-item" type="url">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="comment">你 的 意 见</label>
                <div class="form-item-wrap">
                    <textarea id="comment" class="form-item"></textarea>
                </div>
            </div>

            <div class="form-submit form-item-wrap">
                <input class="btn btn-primary btn-lg" type="submit" value="提 交 意 见">
            </div>
        </form>
		</br>
		<hr>
    </div>
    <?php else : ?>
    <?php endif; ?>
    </div>

<!-- END: PAGE CONTENT -->


		<section class="section clear-mrg">
            <div class="padd-box-sm">
                <ul class="clients">
                    <li><center><a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=1260157543&site=qq&menu=yes"><img src="<?php bloginfo('template_url'); ?>/img/uploads/logos/logo-wordpress.png" srcset="<?php bloginfo('template_url'); ?>/img/uploads/logos/logo-wordpress.png 2x" alt="扫描加QQ"></a></center></li><li>
                        <center><img src="<?php bloginfo('template_url'); ?>/img/uploads/logos/logo-compass.png" srcset="<?php bloginfo('template_url'); ?>/img/uploads/logos/logo-compass.png 2x" alt="扫描加微信"></center></li><li>
                        <center><a  target="_blank" href="http://weibo.com/lyy250250"><img src="<?php bloginfo('template_url'); ?>/img/uploads/logos/logo-bootstrap.png" srcset="<?php bloginfo('template_url'); ?>/img/uploads/logos/logo-bootstrap.png 2x" alt="点击看微博"></a></center></li>
                </ul>
            </div><!-- .padd-box-sm -->
        </section><!-- .section -->
						
                </div><!-- .ace-paper-cont -->
            </main><!-- .ace-paper -->
        </div><!-- .ace-paper-stock -->
		

        </div><!-- .ace-container -->
    </div><!-- #ace-content -->

	<?php get_sidebar(); ?>
<?php get_footer(); ?>
