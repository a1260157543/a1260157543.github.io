<footer id="ace-footer" class="ace-container-shift">
        <div class="ace-container">
			<div class="ace-footer-cont clear-mrg">
				<p class="text-center">Copyright © 2017 <a href="<?php echo get_option('home'); ?>/">林洋洋博客</a>（ICP备案：<a href="http://www.miitbeian.gov.cn" target="_blank">鲁ICP备15043656号</a>）<!--( <a title="林洋洋 | 登录"  href="wp-login.php"><登录> </a> <?php   
    global $current_user, $display_name , $user_email;  
    get_currentuserinfo();  
	echo $current_user->display_name . "\n";   
    ?> )--> All rights reserved.<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1261726632'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s4.cnzz.com/z_stat.php%3Fid%3D1261726632%26show%3Dpic' type='text/javascript'%3E%3C/script%3E"));</script></p>	
        </div><!-- .ace-container -->
    </footer><!-- #ace-footer -->

    <!-- Triangle Shapes -->
    <svg id="ace-bg-shape-1" class="hidden-sm hidden-xs" height="519" width="758">
        <polygon points="0,455,693,352,173,0,92,0,0,71" style="fill:#d2d2d2;stroke:purple;stroke-width:0; opacity: 0.5">
    </svg>

    <svg id="ace-bg-shape-2" class="hidden-sm hidden-xs" height="536" width="633">
        <polygon points="0,0,633,0,633,536" style="fill:#c0e3e7;stroke:purple;stroke-width:0" />
    </svg>
</div><!-- .ace-wrapper -->
<?php wp_footer(); ?>

<div></div>
<a name="gobottom"></a>
<div class="go">
    	<embed id="bgsound" autostart="true" height="0" loop="false" src="<?php bloginfo('template_url'); ?>/img/intro.mp3" width="0">
	<!--<a title="返回顶部" class="top" href="#gotop">至顶</a>
	<a title="如果您有意见，请反馈给我们！" class="feedback" href="#">留言</a>
	<a title="返回底部" class="bottom" href="#gobottom">至底</a>-->
</div>
<!-- Scripts -->
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/vendor/jquery-1.12.4.min.js"></script>
<!---<script type="text/javascript" src="http://ditu.google.cn/maps/api/js?key=AIzaSyDiwY_5J2Bkv2UgSeJa4NOKl6WUezSS9XA"></script>--->
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/plugins/highlight/highlight.pack.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/plugins/jquery.mCustomScrollbar.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/plugins/isotope.pkgd.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/plugins/progressbar.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/plugins/slick.min.js"></script>

<script type="text/javascript" language="javascript">
// Hide loader when page content has load
$(window).on('load', function() {
	$("#loader").fadeOut("slow");
});
(function() {
    function k(a, b, c) {
        if (a.addEventListener) a.addEventListener(b, c, false);
        else a.attachEvent && a.attachEvent("on" + b, c)
    }
    function g(a) {
        if (typeof window.onload != "function") window.onload = a;
        else {
            var b = window.onload;
            window.onload = function() {
                b();
                a()
            }
        }
    }
    function h() {
        var a = {};
        for (type in {
            Top: "",
            Left: ""
        }) {
            var b = type == "Top" ? "Y": "X";
            if (typeof window["page" + b + "Offset"] != "undefined") 
a[type.toLowerCase()] = window["page" + b + "Offset"];
            else {
b = document.documentElement.clientHeight ? document.documentElement: document.body;
                a[type.toLowerCase()] = b["scroll" + type]
            }
        }
        return a
    }
    function l() {
        var a = document.body,
        b;
        if (window.innerHeight) b = window.innerHeight;
        else if (a.parentElement.clientHeight) b = a.parentElement.clientHeight;
        else if (a && a.clientHeight) b = a.clientHeight;
        return b
    }
    function i(a) {
        this.parent = document.body;
        this.createEl(this.parent, a);
        this.size = Math.random() * 14 + 5;
        this.el.style.width = Math.round(this.size) + "px";
        this.el.style.height = Math.round(this.size) + "px";
        this.maxLeft = document.body.offsetWidth - this.size;
        this.maxTop = document.body.offsetHeight - this.size;
        this.left = Math.random() * this.maxLeft;
        this.top = h().top + 1;
        this.angle = 1.4 + 0.2 * Math.random();
        this.minAngle = 1.6;
        this.maxAngle = 3;
        this.angleDelta = 0.01 * Math.random();
        this.speed = 2 + Math.random()
    }
    var j = false;
    g(function() {
        j = true
    });
    var f = true;
    window.createSnow = function(a, b) {
        if (j) {
            var c = [],
            m = setInterval(function() {
                f && b > c.length && Math.random() 
< b * 0.0025 && c.push(new i(a)); ! f && !c.length && clearInterval(m);
                for (var e = h().top, n = l(), d = c.length - 1; d >= 0; d--) 
if (c[d]) if (c[d].top < e || c[d].top + c[d].size + 1 > e + n) {
                    c[d].remove();
                    c[d] = null;
                    c.splice(d, 1)
                } else {
                    c[d].move();
                    c[d].draw()
                }
            },
            40);
            k(window, "scroll",
            function() {
                for (var e = c.length - 1; e >= 0; e--) c[e].draw()
            })
        } else g(function() {
            createSnow(a, b)
        })
    };
    window.removeSnow = function() {
        f = false
    };
    i.prototype = {
        createEl: function(a, b) {
            this.el = document.createElement("img");
            this.el.setAttribute
("src", b + "<?php bloginfo('template_url'); ?>/img/shui.png");
            this.el.style.position = "absolute";
            this.el.style.display = "block";
            this.el.style.zIndex = "99999";
            this.parent.appendChild(this.el)
        },
        move: function() {
            if (this.angle < this.minAngle || this.angle > this.maxAngle) 
this.angleDelta = -this.angleDelta;
            this.angle += this.angleDelta;
            this.left += this.speed * Math.cos(this.angle * Math.PI);
            this.top -= this.speed * Math.sin(this.angle * Math.PI);
            if (this.left < 0) this.left = this.maxLeft;
            else if (this.left > this.maxLeft) this.left = 0
        },
        draw: function() {
            this.el.style.top = Math.round(this.top) + "px";
            this.el.style.left = Math.round(this.left) + "px"
        },
        remove: function() {
            this.parent.removeChild(this.el);
            this.parent = this.el = null
        }
    }
})();
createSnow("", 40);


$(document).ready(function() { 
	$.fn.postLike = function() {
		if ($(this).hasClass('done')) {
			alert('您已赞过了');
			return false;
		} else {
			$(this).addClass('done');
			var id = $(this).data("id"),
			action = $(this).data('action'),
			rateHolder = $(this).children('.count');
			var ajax_data = {
				action: "bigfa_like",
				um_id: id,
				um_action: action
			};
			$.post("<?php bloginfo('url');?>/wp-admin/admin-ajax.php", ajax_data, function(data) {
				$(rateHolder).html(data);
			});
			return false;
		}
	};
	$(document).on("click", ".favorite", function() {
		$(this).postLike();
	});
}); 
</script>

<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/options.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/main.js"></script>
</body>
</html>